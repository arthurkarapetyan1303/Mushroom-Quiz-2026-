package com.example.mushroomquiz

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private const val QUESTIONS_PER_GAME = 10
private const val OPTIONS_PER_QUESTION = 4

data class QuizQuestion(
    val mushroom: Mushroom,
    val options: List<Mushroom>
)

enum class Screen { START, QUIZ, RESULT }

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("ru", "RU"))
            }
        }

        setContent {
            MaterialTheme {
                MushroomQuizApp(speak = ::speak)
            }
        }
    }

    private fun speak(text: String) {
        tts?.stop()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "quiz_utterance")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

fun buildQuizQuestions(): List<QuizQuestion> {
    val chosen = MushroomRepository.all.shuffled().take(QUESTIONS_PER_GAME)
    return chosen.map { correct ->
        val distractors = MushroomRepository.all
            .filter { it.id != correct.id }
            .shuffled()
            .take(OPTIONS_PER_QUESTION - 1)
        QuizQuestion(correct, (distractors + correct).shuffled())
    }
}

@Composable
fun MushroomQuizApp(speak: (String) -> Unit) {
    var screen by remember { mutableStateOf(Screen.START) }
    var questions by remember { mutableStateOf(emptyList<QuizQuestion>()) }
    var currentIndex by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var selectedAnswerId by remember { mutableStateOf<String?>(null) }
    var answered by remember { mutableStateOf(false) }

    fun startGame() {
        questions = buildQuizQuestions()
        currentIndex = 0
        score = 0
        selectedAnswerId = null
        answered = false
        screen = Screen.QUIZ
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF7F3E8)) {
        when (screen) {
            Screen.START -> StartScreen(onStart = ::startGame)
            Screen.QUIZ -> {
                if (questions.isEmpty()) {
                    screen = Screen.START
                } else {
                    val question = questions[currentIndex]
                    LaunchedEffect(currentIndex) {
                        answered = false
                        selectedAnswerId = null
                        speak("Вопрос ${currentIndex + 1}. Какой гриб изображён на картинке?")
                    }

                    QuizScreen(
                        question = question,
                        questionNumber = currentIndex + 1,
                        totalQuestions = QUESTIONS_PER_GAME,
                        score = score,
                        answered = answered,
                        selectedAnswerId = selectedAnswerId,
                        onAnswerSelected = { mushroom ->
                            if (!answered) {
                                answered = true
                                selectedAnswerId = mushroom.id
                                val correct = mushroom.id == question.mushroom.id
                                if (correct) {
                                    score += 1
                                    speak("Правильно! Это ${question.mushroom.nameRu}. ${edibilityText(question.mushroom)}")
                                } else {
                                    speak("Неверно. Это ${question.mushroom.nameRu}. ${edibilityText(question.mushroom)}")
                                }
                            }
                        },
                        onNext = {
                            if (currentIndex + 1 < QUESTIONS_PER_GAME) currentIndex += 1
                            else screen = Screen.RESULT
                        }
                    )
                }
            }
            Screen.RESULT -> {
                LaunchedEffect(Unit) {
                    val percent = score * 100 / QUESTIONS_PER_GAME
                    speak("Игра окончена. Ваш результат: $score из $QUESTIONS_PER_GAME. Правильных ответов $percent процентов.")
                }
                ResultScreen(score, QUESTIONS_PER_GAME, ::startGame)
            }
        }
    }
}

private fun edibilityText(mushroom: Mushroom): String =
    if (mushroom.edible) "Гриб считается съедобным." else "Гриб несъедобный или ядовитый. Не употребляйте его в пищу."

@Composable
fun StartScreen(onStart: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🍄 Грибная Викторина", fontSize = 32.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Text(
            "Угадайте $QUESTIONS_PER_GAME грибов по реальным фотографиям.\nПосле ответа вы увидите, съедобен гриб или нет.\nВопросы озвучиваются голосом.",
            fontSize = 16.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        Button(onClick = onStart) { Text("Начать игру", fontSize = 18.sp) }
        Spacer(Modifier.height(18.dp))
        Text(
            "Фотографии загружаются с Wikimedia Commons. Для загрузки фото нужен интернет.",
            fontSize = 12.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun QuizScreen(
    question: QuizQuestion,
    questionNumber: Int,
    totalQuestions: Int,
    score: Int,
    answered: Boolean,
    selectedAnswerId: String?,
    onAnswerSelected: (Mushroom) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text("Вопрос $questionNumber из $totalQuestions", fontWeight = FontWeight.Medium)
            Text("Баллы: $score", fontWeight = FontWeight.Medium)
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "Какой гриб изображён на фотографии?",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            question.mushroom.latin,
            fontSize = 13.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(top = 3.dp)
        )

        Spacer(Modifier.height(12.dp))
        MushroomPhoto(
            mushroom = question.mushroom,
            modifier = Modifier
                .fillMaxWidth()
                .height(320.dp)
                .clip(RoundedCornerShape(20.dp))
        ) {
            Text("Не удалось загрузить фото", color = Color.Gray)
        }

        Spacer(Modifier.height(12.dp))
        question.options.forEach { option ->
            val isSelected = selectedAnswerId == option.id
            val isCorrectOption = option.id == question.mushroom.id
            val backgroundColor = when {
                !answered -> Color.White
                isCorrectOption -> Color(0xFFBEE7B8)
                isSelected -> Color(0xFFF3B0B0)
                else -> Color.White
            }
            Button(
                onClick = { onAnswerSelected(option) },
                enabled = !answered,
                colors = ButtonDefaults.buttonColors(
                    containerColor = backgroundColor,
                    disabledContainerColor = backgroundColor
                ),
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
            ) {
                Text(option.nameRu, color = Color.Black)
            }
        }

        if (answered) {
            Spacer(Modifier.height(8.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (question.mushroom.edible) Color(0xFFE7F4E4) else Color(0xFFFFE5E5)
                )
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(
                        if (question.mushroom.edible) "🍽 Съедобный гриб" else "⚠️ Несъедобный / ядовитый гриб",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = if (question.mushroom.edible) Color(0xFF176B2C) else Color(0xFF9B1C1C)
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(question.mushroom.fact, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) {
                Text(if (questionNumber < totalQuestions) "Следующий вопрос" else "Показать результат")
            }
        }
    }
}

@Composable
fun ResultScreen(score: Int, total: Int, onPlayAgain: () -> Unit) {
    val percent = score * 100 / total
    val message = when {
        percent == 100 -> "🏆 Великолепно! Вы настоящий грибник!"
        percent >= 80 -> "🌲 Отличный результат!"
        percent >= 60 -> "🍄 Хорошо! Ещё немного практики."
        percent >= 40 -> "🔎 Есть куда расти — попробуйте ещё раз."
        else -> "📚 Самое время познакомиться с грибами поближе!"
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Игра окончена!", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        Text("$percent%", fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
        Text("правильных ответов", fontSize = 18.sp, color = Color.Gray)
        Spacer(Modifier.height(10.dp))
        Text("$score из $total", fontSize = 22.sp)
        Spacer(Modifier.height(20.dp))
        Text(message, fontSize = 17.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(30.dp))
        Button(onClick = onPlayAgain) { Text("Играть снова", fontSize = 18.sp) }
    }
}

package com.example.mushroomquiz

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

private val imageCache = object : LruCache<String, Bitmap>(24 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
}

private fun downloadMushroomPhoto(latin: String): Bitmap? {
    val cached = imageCache.get(latin)
    if (cached != null) return cached

    val encoded = URLEncoder.encode(latin, "UTF-8")
    val apiUrl = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrsearch=" +
            encoded + "&gsrnamespace=6&gsrlimit=1&prop=imageinfo&iiprop=url"

    return try {
        val apiConnection = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 10000
            requestProperty("User-Agent", "MushroomQuiz/1.0 (educational Android app)")
        }
        val json = apiConnection.inputStream.bufferedReader().use { it.readText() }
        apiConnection.disconnect()

        val pages = JSONObject(json).optJSONObject("query")?.optJSONObject("pages") ?: return null
        val keys = pages.keys()
        var imageUrl: String? = null
        while (keys.hasNext() && imageUrl == null) {
            val page = pages.getJSONObject(keys.next())
            val info = page.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val license = info.optJSONObject("extmetadata")?.optJSONObject("LicenseShortName")?.optString("value", "")?.lowercase() ?: ""
            val allowed = license.contains("cc0") || license.contains("public domain") || license == "pd" || license.contains("cc by")
            if (allowed) imageUrl = info.optString("url", null)
        }
        if (imageUrl.isNullOrBlank()) return null

        val imageConnection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 12000
            requestProperty("User-Agent", "MushroomQuiz/1.0 (educational Android app)")
        }
        val bitmap = imageConnection.inputStream.use { BitmapFactory.decodeStream(it) }
        imageConnection.disconnect()

        if (bitmap != null) imageCache.put(latin, bitmap)
        bitmap
    } catch (_: Exception) {
        null
    }
}

@Composable
fun MushroomPhoto(
    mushroom: Mushroom,
    modifier: Modifier = Modifier,
    fallback: @Composable () -> Unit
) {
    var bitmap by remember(mushroom.latin) { mutableStateOf<Bitmap?>(imageCache.get(mushroom.latin)) }
    var loading by remember(mushroom.latin) { mutableStateOf(bitmap == null) }

    LaunchedEffect(mushroom.latin) {
        if (bitmap == null) {
            loading = true
            bitmap = withContext(Dispatchers.IO) { downloadMushroomPhoto(mushroom.latin) }
            loading = false
        }
    }

    Box(
        modifier = modifier.background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        when {
            bitmap != null -> Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = mushroom.nameRu,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )
            loading -> CircularProgressIndicator()
            else -> fallback()
        }
    }
}

# Список видов и запросы для поиска реальных фото (Wikimedia Commons)

| id (имя файла) | Русское название | Латинское название | Съедобен | Запрос для поиска фото |
|---|---|---|---|---|
| belyi_grib | Белый гриб | Boletus edulis | да | Boletus edulis |
| podberezovik_obyknovennyi | Подберёзовик обыкновенный | Leccinum scabrum | да | Leccinum scabrum |
| podberezovik_chernyi | Подберёзовик чёрный | Leccinum melaneum | да | Leccinum melaneum |
| podosinovik_krasnyi | Подосиновик красный | Leccinum aurantiacum | да | Leccinum aurantiacum |
| podosinovik_zhelto_buryi | Подосиновик жёлто-бурый | Leccinum versipelle | да | Leccinum versipelle |
| mohovik_zelenyi | Моховик зелёный | Xerocomus subtomentosus | да | Xerocomus subtomentosus |
| mohovik_pestryi | Моховик пёстрый | Xerocomus chrysenteron | да | Xerocomus chrysenteron |
| dubovik_obyknovennyi | Дубовик обыкновенный | Boletus luridus | да | Boletus luridus |
| dubovik_krapchatyi | Дубовик крапчатый | Boletus erythropus | да | Boletus erythropus |
| polskii_grib | Польский гриб | Xerocomus badius | да | Xerocomus badius |
| zhelchnyi_grib | Желчный гриб | Tylopilus felleus | нет/ядовит | Tylopilus felleus |
| kozlyak | Козляк | Suillus bovinus | да | Suillus bovinus |
| maslenok_zernistyi | Масленок зернистый | Suillus granulatus | да | Suillus granulatus |
| maslenok_pozdnii | Масленок поздний | Suillus luteus | да | Suillus luteus |
| satanas | Сатанинский гриб | Boletus satanas | нет/ядовит | Boletus satanas |
| lisichka_obyknovennaya | Лисичка обыкновенная | Cantharellus cibarius | да | Cantharellus cibarius |
| lisichka_seraya | Лисичка серая | Craterellus cornucopioides | да | Craterellus cornucopioides |
| muhomor_krasnyi | Мухомор красный | Amanita muscaria | нет/ядовит | Amanita muscaria |
| muhomor_panternyi | Мухомор пантерный | Amanita pantherina | нет/ядовит | Amanita pantherina |
| muhomor_porfirovyi | Мухомор порфировый | Amanita porphyria | нет/ядовит | Amanita porphyria |
| poplavok_seryi | Поплавок серый | Amanita vaginata | да | Amanita vaginata |
| poplavok_zheltyi | Поплавок жёлтый | Amanita crocea | да | Amanita crocea |
| blednaya_poganka | Бледная поганка | Amanita phalloides | нет/ядовит | Amanita phalloides |
| muhomor_vonyuchii | Мухомор вонючий | Amanita virosa | нет/ядовит | Amanita virosa |
| gruzd_nastoyashchii | Груздь настоящий | Lactarius resimus | да | Lactarius resimus |
| gruzd_chernyi | Груздь чёрный | Lactarius necator | да | Lactarius necator |
| gruzd_osinovyi | Груздь осиновый | Lactarius controversus | да | Lactarius controversus |
| volnushka_rozovaya | Волнушка розовая | Lactarius torminosus | да | Lactarius torminosus |
| volnushka_belaya | Волнушка белая | Lactarius pubescens | да | Lactarius pubescens |
| ryzhik | Рыжик | Lactarius deliciosus | да | Lactarius deliciosus |
| skripitsa | Скрипица | Lactarius vellereus | да | Lactarius vellereus |
| podgruzdok_belyi | Подгруздок белый | Russula delica | да | Russula delica |
| syroezhka_pishchevaya | Сыроежка пищевая | Russula vesca | да | Russula vesca |
| syroezhka_zelenaya | Сыроежка зелёная | Russula aeruginea | да | Russula aeruginea |
| syroezhka_zhguchaya | Сыроежка жгучеедкая | Russula emetica | нет/ядовит | Russula emetica |
| valui | Валуй | Russula foetens | да | Russula foetens |
| shampinion | Шампиньон | Agaricus bisporus | да | Agaricus bisporus |
| shampinion_lesnoi | Шампиньон лесной | Agaricus sylvaticus | да | Agaricus sylvaticus |
| shampinion_polevoi | Шампиньон полевой | Agaricus arvensis | да | Agaricus arvensis |
| veshenka | Вешенка | Pleurotus ostreatus | да | Pleurotus ostreatus |
| openok_osennii | Опёнок осенний | Armillaria mellea | да | Armillaria mellea |
| openok_letnii | Опёнок летний | Kuehneromyces mutabilis | да | Kuehneromyces mutabilis |
| openok_lugovoi | Опёнок луговой | Marasmius oreades | да | Marasmius oreades |
| openok_zimnii | Опёнок зимний | Flammulina velutipes | да | Flammulina velutipes |
| lozhnoopenok_sero_zheltyi | Ложноопёнок серо-жёлтый | Hypholoma fasciculare | нет/ядовит | Hypholoma fasciculare |
| openok_kirpichno_krasnyi | Опёнок ложный кирпично-красный | Hypholoma sublateritium | нет/ядовит | Hypholoma sublateritium |
| smorchok | Сморчок | Morchella esculenta | да | Morchella esculenta |
| smorchkovaya_shapochka | Сморчковая шапочка | Mitrophora semilibera | да | Mitrophora semilibera |
| strochok | Строчок обыкновенный | Gyromitra esculenta | нет/ядовит | Gyromitra esculenta |
| navoznik_seryi | Навозник серый | Coprinus comatus | да | Coprinus comatus |
| navoznik_belyi | Навозник белый | Coprinus comatus var. | да | Coprinus comatus var. |
| govorushka | Говорушка | Clitocybe nebularis | да | Clitocybe nebularis |
| govorushka_zemlisto_seraya | Говорушка беловатая | Clitocybe dealbata | нет/ядовит | Clitocybe dealbata |
| zontik_pestryi | Гриб-зонтик пёстрый | Macrolepiota procera | да | Macrolepiota procera |
| zontik_devichii | Гриб-зонтик девичий | Macrolepiota mastoidea | да | Macrolepiota mastoidea |
| dozhdevik | Дождевик обыкновенный | Lycoperdon perlatum | да | Lycoperdon perlatum |
| dozhdevik_gigantskii | Дождевик гигантский | Calvatia gigantea | да | Calvatia gigantea |
| golovach | Головач продолговатый | Bovista plumbea | да | Bovista plumbea |
| svinushka_tonkaya | Свинушка тонкая | Paxillus involutus | нет/ядовит | Paxillus involutus |
| ryadovka_seraya | Рядовка серая | Tricholoma portentosum | да | Tricholoma portentosum |
| ryadovka_fioletovaya | Рядовка фиолетовая | Lepista nuda | да | Lepista nuda |
| ryadovka_zemlistaya | Рядовка землистая | Tricholoma terreum | да | Tricholoma terreum |
| mokruha_elovaya | Мокруха еловая | Gomphidius glutinosus | да | Gomphidius glutinosus |
| ezhovik_zheltyi | Ежовик жёлтый | Hydnum repandum | да | Hydnum repandum |
| trutovik_serno_zheltyi | Трутовик серно-жёлтый | Laetiporus sulphureus | да | Laetiporus sulphureus |
| chaga | Чага | Inonotus obliquus | нет/ядовит | Inonotus obliquus |
| truffel_letnii | Трюфель летний | Tuber aestivum | да | Tuber aestivum |

**Всего видов в базе: 67**

Скачивайте только фото с лицензией CC0, Public Domain или CC-BY на Wikimedia
Commons (https://commons.wikimedia.org) — это можно свободно использовать.
Не забудьте указать авторов в разделе «О приложении», если лицензия CC-BY
этого требует.